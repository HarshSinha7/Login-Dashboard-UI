package com.practice.database;

import com.practice.beans.SignUp;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class Database {
    List<SignUp> list=new ArrayList<>();
}
